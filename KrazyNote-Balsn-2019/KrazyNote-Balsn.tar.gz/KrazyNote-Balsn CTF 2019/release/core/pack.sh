#!/bin/bash

find . | cpio -o --format=newc > ../rootfs.img
