gdb -n \
    -ex "add-auto-load-safe-path $(pwd)" \
    -ex "file ./vmlinux" \
    -ex 'set arch i386:x86-64' \
    -ex 'target remote localhost:1234' \
    -ex 'continue' \
    -ex 'disconnect' \
    -ex 'set arch i386:x86-64' \
    -ex 'target remote localhost:1234' \
    -ex 'add-symbol-file ./note.ko 0xffffffffc0000000' \
    -ex 'b *0xffffffffc0000162' \
    -ex 'b *0xffffffffc00001cc' \
    -ex 'b *0xffffffffc000006c' \
    -ex 'continue' \
    -ex 'layout split' \
    -ex 'layout regs' \
    -ex 'focus cmd' \

